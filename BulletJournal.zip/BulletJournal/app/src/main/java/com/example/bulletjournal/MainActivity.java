package com.example.bulletjournal;

import android.os.Bundle;


import com.example.bulletjournal.ui.main.DayFragment;
import com.example.bulletjournal.ui.main.MonthFragment;
import com.example.bulletjournal.ui.main.StatsFragment;
import com.google.android.material.tabs.TabLayout;

import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.example.bulletjournal.ui.main.SectionsPagerAdapter;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ViewPager viewPager = findViewById(R.id.view_pager);
        TabLayout tabs = findViewById(R.id.tabs);

        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager()/*, tabs.getTabCount()*/);

        sectionsPagerAdapter.addFragment(new DayFragment(), "Day");
        sectionsPagerAdapter.addFragment(new MonthFragment(), "Month");
        sectionsPagerAdapter.addFragment(new StatsFragment(), "Stats");
        /*// Create a new Tab named "Day"
        TabLayout.Tab day = tabs.newTab();
        day.setText("Day"); // set the Text for the first Tab
        // first tab
        tabs.addTab(day); // add  the tab at in the TabLayout

        // Create a new Tab named "Month"
        TabLayout.Tab month = tabs.newTab();
        month.setText("Month"); // set the Text for the second Tab
        tabs.addTab(month); // add  the tab  in the TabLayout

        // Create a new Tab named "Stats"
        TabLayout.Tab stats = tabs.newTab();
        stats.setText("Stats"); // set the Text for the first Tab
        tabs.addTab(stats); // add  the tab at in the TabLayout*/

        viewPager.setAdapter(sectionsPagerAdapter);
        tabs.setupWithViewPager(viewPager);

    }
}